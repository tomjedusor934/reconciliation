from sqlalchemy import BigInteger, Column, Index, Numeric, String, UniqueConstraint

from app.db.base import Base


class EntryPaymentStatus(Base):
    """Status of one payment (std.Payment) behind one reconciliation entry.

    A bulk movement settles N payments → N rows per entry; singles/returns
    have exactly one. Synced from the datamart by the sync_payment_status DAG
    task (the app has no MSSQL access) and re-refreshed while the entry is
    still live. Read by the operational view as a per-entry aggregate
    ("3 ACC · 2 PDNG").
    """

    __tablename__ = "entry_payment_status"
    __table_args__ = (
        UniqueConstraint("entry_id", "po_id", name="uq_entry_payment_status_entry_po"),
        Index("ix_entry_payment_status_entry_id", "entry_id"),
        Index("ix_entry_payment_status_po_id", "po_id"),
        {"schema": "reco"},
    )

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    # reconciliation_entry is partitioned → logical reference, NO FK (same
    # convention as Exclusion.entry_id). The id is preserved when an entry
    # moves to the émargement table, so the join works for both.
    entry_id = Column(BigInteger, nullable=False)
    po_id = Column(String(64), nullable=False)  # = std.Payment.PaymentNumber
    status = Column(String(32), nullable=True)  # = std.Payment.Status
    # = the payment's amount (std.Payment). Nullable: existing rows stay NULL
    # until the sync_payment_status DAG re-runs (PS_FULL_SYNC backfills). The
    # lot view sums this over a lot's PDNG payments to show the real pending
    # amount (precise even for partially-pending bulks, where the member's own
    # amount would over-count).
    amount = Column(Numeric(20, 4), nullable=True)
