"""Reconciliation engine — automatic, forced, and exclusion logic."""
from __future__ import annotations

import io
import logging
from datetime import datetime, timezone
from decimal import Decimal
from typing import List, Optional, Tuple

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from sqlalchemy.orm import Session

from app.db.locks import LockKey, try_advisory_lock
from app.models.exclusion import Exclusion
from app.models.flow import Flow
from app.models.match_group import MatchGroup, MatchMode
from app.models.reconciliation_entry import EntryStatus
from app.models.reconciliation_run import ReconciliationRun
from app.repositories.exclusion_repository import exclusion_repository
from app.repositories.match_group_repository import match_group_repository
from app.repositories.reconciliation_entry_repository import reconciliation_entry_repository
from app.repositories.reconciliation_run_repository import reconciliation_run_repository
from app.services.payment_status_service import payment_status_service

logger = logging.getLogger(__name__)


class ReconciliationAlreadyRunning(ValueError):
    """Another process holds the reconciliation_entry writer lock — a run_auto
    or an émargement sweep is already in progress.

    Subclasses ValueError to follow the repo's typed business-error convention
    (cf. CrossLotKeyConflict), but the endpoints map it to 200/skipped rather
    than a 4xx: nothing is wrong, someone else is simply doing the work.
    """


class ReconciliationService:
    # --------------------------------------------------------------
    # List / query helpers
    # --------------------------------------------------------------
    def list_runs(self, db: Session, *, skip: int = 0, limit: int = 100) -> list:
        return reconciliation_run_repository.list(db, skip=skip, limit=limit)

    def list_entries_filtered(
        self,
        db: Session,
        *,
        flow_id=None,
        status=None,
        reco_id=None,
        amount_min=None,
        amount_max=None,
        payment_statuses=None,
        account=None,
        date_from=None,
        date_to=None,
        search=None,
        skip: int = 0,
        limit: int = 100,
        with_payment_statuses: bool = True,
    ):
        filter_kwargs = dict(
            flow_id=flow_id,
            status=status,
            reco_id=reco_id,
            amount_min=amount_min,
            amount_max=amount_max,
            payment_statuses=payment_statuses,
            account=account,
            date_from=date_from,
            date_to=date_to,
            search=search,
        )
        items = reconciliation_entry_repository.list_filtered(db, **filter_kwargs, skip=skip, limit=limit)
        total_count = reconciliation_entry_repository.count_filtered(db, **filter_kwargs)
        if with_payment_statuses:
            # Per-entry payment statuses ("3 ACC · 2 PDNG" in the operational
            # view) — one aggregate query for the page; ids are preserved
            # across live/émargement so rows from either table resolve.
            agg = payment_status_service.aggregate_for_entries(
                db, entry_ids=[e.id for e in items]
            )
            for entry in items:
                setattr(entry, "payment_statuses", agg.get(entry.id))
        return items, total_count

    def distinct_payment_statuses(self, db: Session) -> List[str]:
        """Distinct payment-status values (for the operational filter options)."""
        return payment_status_service.distinct_statuses(db)

    def export_entries_excel(self, db: Session, *, filters) -> io.BytesIO:
        """Generate an Excel file with every entry matching ``filters``.

        Mirrors the archive export (``time_machine_service.export_snapshot_excel``):
        one styled "Entries" sheet, fetched with no pagination so the file holds
        all matching rows — not just the 200-row batches the operational view
        lazy-loads. Internal identifiers (db id, numeric flow_id, run / match ids)
        are intentionally omitted; the flow is shown by its human-readable code.
        """
        items, _ = self.list_entries_filtered(
            db,
            flow_id=filters.flow_id,
            status=filters.status,
            reco_id=filters.reco_id,
            amount_min=filters.amount_min,
            amount_max=filters.amount_max,
            payment_statuses=filters.payment_statuses,
            account=filters.account,
            date_from=filters.date_from,
            date_to=filters.date_to,
            search=filters.search,
            skip=0,
            limit=100_000,
            with_payment_statuses=True,  # export mirrors the table's "Payments" column
        )

        # flow_id → code so the export shows the same label as the UI table.
        flow_codes = {f.id: f.code for f in db.query(Flow).all()}

        wb = Workbook()
        ws = wb.active
        ws.title = "Entries"

        header_fill = PatternFill(start_color="2B2D42", end_color="2B2D42", fill_type="solid")
        header_text = Font(bold=True, color="FFFFFF")
        headers = [
            "Flow", "Reco ID", "Account", "Currency", "Amount", "Direction",
            "Value date", "Operation date", "Event type", "External ref",
            "File name", "Particulars", "Ref no", "Remarks 1", "Status", "Matched at",
            "Payments",
        ]
        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.font = header_text
            cell.fill = header_fill

        def _enum(v):
            return v.value if v is not None else None

        def _dt(v):
            return str(v) if v else ""

        def _payments(e):
            # Same "3 ACC · 2 PDNG" rendering as the operational table's pills:
            # {status: count} sorted by count desc then status.
            agg = getattr(e, "payment_statuses", None)
            if not agg:
                return ""
            return " · ".join(
                f"{count} {status}"
                for status, count in sorted(agg.items(), key=lambda kv: (-kv[1], kv[0]))
            )

        for row_idx, e in enumerate(items, 2):
            ws.cell(row=row_idx, column=1, value=flow_codes.get(e.flow_id, f"#{e.flow_id}"))
            ws.cell(row=row_idx, column=2, value=e.reco_id)
            ws.cell(row=row_idx, column=3, value=e.account)
            ws.cell(row=row_idx, column=4, value=e.currency)
            ws.cell(row=row_idx, column=5, value=float(e.amount) if e.amount is not None else None)
            ws.cell(row=row_idx, column=6, value=_enum(e.direction))
            ws.cell(row=row_idx, column=7, value=_dt(e.value_date))
            ws.cell(row=row_idx, column=8, value=_dt(e.operation_date))
            ws.cell(row=row_idx, column=9, value=e.event_type)
            ws.cell(row=row_idx, column=10, value=e.external_ref)
            ws.cell(row=row_idx, column=11, value=e.file_name)
            ws.cell(row=row_idx, column=12, value=e.transaction_particulars)
            ws.cell(row=row_idx, column=13, value=e.ref_no)
            ws.cell(row=row_idx, column=14, value=e.remarks_1)
            ws.cell(row=row_idx, column=15, value=_enum(e.status))
            ws.cell(row=row_idx, column=16, value=_dt(e.matched_at))
            ws.cell(row=row_idx, column=17, value=_payments(e))

        # Auto-width columns (cap at 40), mirroring the archive export.
        for col in ws.columns:
            max_length = 0
            col_letter = col[0].column_letter
            for cell in col:
                if cell.value is not None:
                    max_length = max(max_length, len(str(cell.value)))
            ws.column_dimensions[col_letter].width = min(max_length + 2, 40)

        output = io.BytesIO()
        wb.save(output)
        output.seek(0)
        return output

    def list_match_groups(self, db: Session, *, flow_id=None, skip: int = 0, limit: int = 100) -> list:
        return match_group_repository.list_filtered(db, flow_id=flow_id, skip=skip, limit=limit)

    # --------------------------------------------------------------
    # File-source reco_id resolution (e.g. MT940 keys → finacle reco_id)
    # --------------------------------------------------------------
    def resolve_pending_references(self, db: Session) -> int:
        """Global safety-net sweep run before matching: fill reco_id for live PENDING
        entries from lookup-enabled file sources (e.g. MT940 +21 keys) from a matching
        finacle entry. Delegates to the repository, which is also used per-flow as the
        first step of file ingestion. Idempotent; returns the number resolved."""
        return reconciliation_entry_repository.resolve_flow_references(db)

    # --------------------------------------------------------------
    # Automatic engine
    # --------------------------------------------------------------
    def run_auto(self, db: Session, *, triggered_by: Optional[str] = None) -> ReconciliationRun:
        """Automatic engine. Single-writer, enforced by a Postgres advisory lock.

        Two concurrent run_auto deadlock each other: mark_matched walks
        reconciliation_entry through ix_reconciliation_entry_flow_status_date (so
        in value_date order) while the other run's move_matched_to_emargement
        walks the very same rows through ix_reconciliation_entry_reco_id —
        opposite lock orders over one set of tuples. Rather than order every
        write, the engine is made single-writer: it is a batch, not a query path,
        and a second concurrent run has no work to do anyway (the first one has
        already consumed the balanced groups).

        The lock is taken BEFORE creating the ReconciliationRun, so that a
        skipped run leaves no phantom finished_at=NULL row behind.
        """
        with try_advisory_lock(LockKey.RECONCILIATION_ENTRY_WRITER) as acquired:
            if not acquired:
                logger.info("reconciliation run skipped: another run holds the lock")
                raise ReconciliationAlreadyRunning(
                    "a reconciliation run is already in progress"
                )
            return self._run_auto_locked(db, triggered_by=triggered_by)

    def _run_auto_locked(self, db: Session, *, triggered_by: Optional[str]) -> ReconciliationRun:
        """Engine body. Only ever called holding RECONCILIATION_ENTRY_WRITER."""
        started = datetime.now(timezone.utc)
        run = reconciliation_run_repository.create(
            db,
            run=ReconciliationRun(started_at=started, triggered_by=triggered_by or "manual"),
        )
        # Captured now: a rollback expires the instance, and touching run.id then
        # fires a fresh SELECT — not something to do from an error handler.
        run_id = run.id
        groups_created = 0
        entries_matched = 0
        try:
            # Resolve reco_id for file entries (e.g. MT940) that reference a finacle
            # movement ingested earlier — so they can match in this run.
            self.resolve_pending_references(db)
            balanced = reconciliation_entry_repository.find_balanced_groups(db)
            for flow_id, reco_id, currency, total in balanced:
                mg = match_group_repository.create(
                    db,
                    mg=MatchGroup(
                        flow_id=flow_id,
                        reco_id=reco_id,
                        currency=currency,
                        total=total,
                        mode=MatchMode.AUTO,
                        created_at=datetime.now(timezone.utc),
                        reconciliation_run_id=run.id,
                    ),
                )
                count = reconciliation_entry_repository.mark_matched(
                    db,
                    flow_id=flow_id,
                    reco_id=reco_id,
                    currency=currency,
                    match_group_id=mg.id,
                )
                # Move matched entries from live to émargement table
                reconciliation_entry_repository.move_matched_to_emargement(
                    db,
                    flow_id=flow_id,
                    reco_id=reco_id,
                    currency=currency,
                )
                groups_created += 1
                entries_matched += count
        except Exception:
            # The failing statement (a deadlock victim, say) leaves the psycopg2
            # transaction aborted: without this rollback every later statement
            # raises InFailedSqlTransaction — including the bookkeeping below,
            # which would then mask the real error and leave the run unfinalized
            # (finished_at NULL) for good.
            db.rollback()
            raise
        finally:
            finished = datetime.now(timezone.utc)
            try:
                reconciliation_run_repository.update(
                    db,
                    run=run,
                    finished_at=finished,
                    groups_created=groups_created,
                    entries_matched=entries_matched,
                    duration_ms=int((finished - started).total_seconds() * 1000),
                )
            except Exception:
                # An exception raised in a finally REPLACES the one propagating.
                # Bookkeeping must never erase the root cause on the way out.
                logger.exception("failed to finalize reconciliation run %s", run_id)
        return run

    # --------------------------------------------------------------
    # Manual forcing
    # --------------------------------------------------------------
    def force_match(
        self,
        db: Session,
        *,
        entry_ids: List[int],
        comment: Optional[str],
        user_id: Optional[int],
    ) -> MatchGroup:
        """Force a manual match. Pre-flight controls per spec:
        - all entries must belong to the same flow
        - same currency
        - sum must be zero (unless an explicit comment justifies otherwise)
        """
        if not entry_ids:
            raise ValueError("at least one entry is required")

        entries = []
        for entry_id in entry_ids:
            e = reconciliation_entry_repository.get_one(db, entry_id=entry_id)
            if e is None:
                raise ValueError(f"entry {entry_id} not found")
            if e.status != EntryStatus.PENDING:
                raise ValueError(f"entry {entry_id} is not pending (status={e.status})")
            entries.append(e)

        flow_ids = {e.flow_id for e in entries}
        if len(flow_ids) != 1:
            raise ValueError("all entries must belong to the same flow")
        currencies = {e.currency for e in entries}
        if len(currencies) != 1:
            raise ValueError("all entries must share the same currency")
        total = sum((e.amount for e in entries), Decimal("0"))
        if total != Decimal("0"):
            raise ValueError("sum is not zero — manual match requires a balanced group (total = 0)")

        flow_id = entries[0].flow_id
        currency = entries[0].currency
        reco_id = next((e.reco_id for e in entries if e.reco_id), None)

        mg = match_group_repository.create(
            db,
            mg=MatchGroup(
                flow_id=flow_id,
                reco_id=reco_id,
                currency=currency,
                total=total,
                mode=MatchMode.FORCED,
                created_by_user_id=user_id,
                created_at=datetime.now(timezone.utc),
                comment=comment,
            ),
        )
        reconciliation_entry_repository.mark_forced(
            db, entry_ids=entry_ids, match_group_id=mg.id
        )
        # Move forced entries to émargement
        reconciliation_entry_repository.move_to_emargement(db, entry_ids=entry_ids)
        return mg

    # --------------------------------------------------------------
    # Manual exclusion
    # --------------------------------------------------------------
    def exclude(
        self,
        db: Session,
        *,
        entry_id: int,
        reason: str,
        user_id: Optional[int],
    ) -> Exclusion:
        if not reason or not reason.strip():
            raise ValueError("exclusion reason is mandatory")
        e = reconciliation_entry_repository.get_one(db, entry_id=entry_id)
        if e is None:
            raise ValueError(f"entry {entry_id} not found")
        if e.status == EntryStatus.MATCHED:
            raise ValueError("cannot exclude an already matched entry")

        excl = exclusion_repository.create(
            db,
            exclusion=Exclusion(
                entry_id=entry_id,
                entry_value_date=e.value_date,
                reason=reason.strip(),
                created_by_user_id=user_id,
                created_at=datetime.now(timezone.utc),
            ),
        )
        reconciliation_entry_repository.mark_excluded(db, entry_id=entry_id)
        # Move excluded entry to émargement
        reconciliation_entry_repository.move_to_emargement(db, entry_ids=[entry_id])
        return excl

    # --------------------------------------------------------------
    # Unexclude (reverse an exclusion)
    # --------------------------------------------------------------
    def unexclude(
        self,
        db: Session,
        *,
        entry_id: int,
        reason: str,
        user_id: Optional[int],
    ) -> Exclusion:
        if not reason or not reason.strip():
            raise ValueError("unexclude reason is mandatory")

        # Entry must exist in émargement with EXCLUDED status
        entry = reconciliation_entry_repository.get_emargement_entry(db, entry_id=entry_id)
        if entry is None:
            raise ValueError(f"entry {entry_id} not found in émargement table")
        if entry.status != EntryStatus.EXCLUDED:
            raise ValueError(f"entry {entry_id} is not excluded (status={entry.status})")

        # Active (non-cancelled) exclusion, if any. It may be None when a previous
        # partial unexclude already cancelled it but failed to move the entry — we
        # still recover by moving the (still EXCLUDED) entry back.
        excl = exclusion_repository.get_active_for_entry(db, entry_id=entry_id)
        records = exclusion_repository.list_for_entry(db, entry_id=entry_id)
        if excl is None and not records:
            raise ValueError(f"no exclusion found for entry {entry_id}")

        # Atomic: move the entry back to live AND cancel the exclusion, commit once.
        try:
            moved = reconciliation_entry_repository.move_from_emargement_to_live(
                db, entry_id=entry_id, commit=False
            )
            if moved == 0:
                db.rollback()
                raise ValueError(
                    f"failed to move entry {entry_id} back to live table "
                    "(it may already exist in the live table)"
                )
            if excl is not None:
                exclusion_repository.cancel(db, exclusion=excl, user_id=user_id, commit=False)
            db.commit()
        except Exception:
            db.rollback()
            raise

        return excl or records[0]


reconciliation_service = ReconciliationService()
