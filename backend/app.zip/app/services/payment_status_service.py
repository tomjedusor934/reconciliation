"""Per-entry payment statuses (std.Payment sync from the DAG).

The DAG never knows backend entry ids: each pushed row carries the entry's
finacle identity fields (external_ref/account/value_date/operation_date) and
the service recomputes the source_hash with the SAME formula as the entry
push path (``lot_service.member_to_source_hash`` — parity locked by
tests/test_lot_hash_parity.py) to resolve the entry id.
"""
import logging
from typing import Any, Dict, List, Sequence

from sqlalchemy.orm import Session

from app.models.flow import Flow
from app.repositories.payment_status_repository import payment_status_repository
from app.services.lot_service import lot_service

logger = logging.getLogger(__name__)


class PaymentStatusService:
    def apply_status_batch(
        self, db: Session, *, flow: Flow, rows: Sequence[Any]
    ) -> Dict[str, int]:
        """Upsert one batch of (entry identity, po_id, status) rows.

        Rows whose entry is not ingested yet are counted ``skipped`` (the DAG
        task runs after the ingest tasks, so this stays marginal; the next run
        re-pushes them anyway).
        """
        hashes = [
            lot_service.member_to_source_hash(
                flow_id=flow.id,
                external_ref=r.external_ref,
                account=r.account,
                value_date=r.value_date,
                operation_date=r.operation_date,
            )
            for r in rows
        ]
        ids_by_hash = payment_status_repository.resolve_entry_ids(
            db, source_hashes=list(set(hashes))
        )
        to_upsert: List[dict] = []
        skipped = 0
        for r, source_hash in zip(rows, hashes):
            entry_id = ids_by_hash.get(source_hash)
            if entry_id is None:
                skipped += 1
                continue
            to_upsert.append(
                {
                    "entry_id": entry_id,
                    "po_id": r.po_id,
                    "status": r.status,
                    "amount": getattr(r, "amount", None),
                }
            )
        inserted, updated, unchanged = payment_status_repository.upsert_statuses(db, to_upsert)
        db.commit()
        if skipped:
            logger.info(
                "[payment_status] flow %s: %d row(s) skipped (entry not ingested yet)",
                flow.code, skipped,
            )
        return {
            "inserted": inserted, "updated": updated,
            "unchanged": unchanged, "skipped": skipped,
        }

    def list_movements(
        self, db: Session, *, flow: Flow, scope: str = "pending",
        skip: int = 0, limit: int = 1000,
    ) -> List[Dict[str, Any]]:
        rows = payment_status_repository.list_movements(
            db, flow_id=flow.id, scope=scope, skip=skip, limit=limit
        )
        return [
            {
                "external_ref": r.external_ref,
                "account": r.account,
                "value_date": r.value_date,
                "operation_date": r.operation_date,
                "transaction_particulars": r.transaction_particulars,
                "ref_no": r.ref_no,
                "remarks_1": r.remarks_1,
                "initiating_channel": r.initiating_channel,
            }
            for r in rows
        ]

    def aggregate_for_entries(
        self, db: Session, *, entry_ids: Sequence[int]
    ) -> Dict[int, Dict[str, int]]:
        return payment_status_repository.aggregate_for_entries(db, entry_ids=entry_ids)

    def distinct_statuses(self, db: Session) -> List[str]:
        return payment_status_repository.distinct_statuses(db)


payment_status_service = PaymentStatusService()
