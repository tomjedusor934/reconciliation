"""Data access for per-entry payment statuses (std.Payment sync).

Write methods NEVER commit — the service owns the transaction, mirroring
movement_lot_repository.
"""
import logging
from typing import Any, Dict, List, Sequence, Tuple

from sqlalchemy import literal_column, text
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import Session

from app.models.payment_status import EntryPaymentStatus

logger = logging.getLogger(__name__)


class PaymentStatusRepository:
    def resolve_entry_ids(self, db: Session, *, source_hashes: Sequence[str]) -> Dict[str, int]:
        """source_hash -> entry id, live table first then émargement (ids are
        preserved when an entry is swept, so either hit is the same id)."""
        if not source_hashes:
            return {}
        rows = db.execute(
            text(
                """
                SELECT source_hash, id FROM reco.reconciliation_entry
                WHERE source_hash = ANY(:hashes)
                UNION
                SELECT source_hash, id FROM reco.reconciliation_entry_emargement
                WHERE source_hash = ANY(:hashes)
                """
            ),
            {"hashes": list(source_hashes)},
        ).fetchall()
        return {r.source_hash: r.id for r in rows}

    def upsert_statuses(self, db: Session, rows: Sequence[dict]) -> Tuple[int, int, int]:
        """Insert/refresh (entry_id, po_id) -> (status, amount); rows whose
        status AND amount are both unchanged are NOT rewritten (WHERE on the
        conflict clause — every run re-pushes all pending movements, most rows
        haven't moved). Returns (inserted, updated, unchanged)."""
        if not rows:
            return 0, 0, 0
        deduped = {(r["entry_id"], r["po_id"]): r for r in rows}
        table = EntryPaymentStatus.__table__
        stmt = pg_insert(table).values(list(deduped.values()))
        stmt = stmt.on_conflict_do_update(
            constraint="uq_entry_payment_status_entry_po",
            set_={
                "status": stmt.excluded.status,
                "amount": stmt.excluded.amount,
                "updated_at": text("now()"),
            },
            where=(
                table.c.status.is_distinct_from(stmt.excluded.status)
                | table.c.amount.is_distinct_from(stmt.excluded.amount)
            ),
        ).returning(literal_column("(xmax = 0)"))
        inserted = updated = 0
        for (is_insert,) in db.execute(stmt).fetchall():
            if is_insert:
                inserted += 1
            else:
                updated += 1
        return inserted, updated, len(deduped) - inserted - updated

    _MOVEMENT_COLUMNS = """
        external_ref, account, value_date, operation_date,
        transaction_particulars, ref_no, remarks_1,
        payload_raw->>'Initiating_channel' AS initiating_channel
    """

    def list_movements(
        self, db: Session, *, flow_id: int, scope: str = "pending",
        skip: int = 0, limit: int = 1000,
    ) -> List[Any]:
        """One page of the flow's movements for the payment-status DAG task:
        the entry's finacle identity + the fields PO derivation reads.
        ``pending`` = live PENDING entries only (the sync perimeter);
        ``all`` = live + émargement (first-launch full sync)."""
        if scope == "all":
            base = f"""
                SELECT {self._MOVEMENT_COLUMNS}, id FROM reco.reconciliation_entry
                WHERE flow_id = :flow_id AND external_ref IS NOT NULL
                UNION ALL
                SELECT {self._MOVEMENT_COLUMNS}, id FROM reco.reconciliation_entry_emargement
                WHERE flow_id = :flow_id AND external_ref IS NOT NULL
                ORDER BY id LIMIT :limit OFFSET :skip
            """
        else:
            base = f"""
                SELECT {self._MOVEMENT_COLUMNS}, id FROM reco.reconciliation_entry
                WHERE flow_id = :flow_id AND status = 'PENDING'
                  AND external_ref IS NOT NULL
                ORDER BY id LIMIT :limit OFFSET :skip
            """
        return db.execute(
            text(base), {"flow_id": flow_id, "limit": limit, "skip": skip}
        ).fetchall()

    def aggregate_for_entries(
        self, db: Session, *, entry_ids: Sequence[int]
    ) -> Dict[int, Dict[str, int]]:
        """entry_id -> {status: count} for one page of the operational view."""
        if not entry_ids:
            return {}
        rows = db.execute(
            text(
                """
                SELECT entry_id, COALESCE(status, '?') AS status, COUNT(*) AS n
                FROM reco.entry_payment_status
                WHERE entry_id = ANY(:ids)
                GROUP BY entry_id, COALESCE(status, '?')
                """
            ),
            {"ids": list(entry_ids)},
        ).fetchall()
        result: Dict[int, Dict[str, int]] = {}
        for r in rows:
            result.setdefault(r.entry_id, {})[r.status] = r.n
        return result

    def distinct_statuses(self, db: Session) -> List[str]:
        """All distinct payment-status values present ('?' = NULL/unknown),
        busiest first — the operational filter's option list."""
        rows = db.execute(
            text(
                """
                SELECT COALESCE(status, '?') AS status, COUNT(*) AS n
                FROM reco.entry_payment_status
                GROUP BY COALESCE(status, '?')
                ORDER BY n DESC, status
                """
            )
        ).fetchall()
        return [r.status for r in rows]


payment_status_repository = PaymentStatusRepository()
