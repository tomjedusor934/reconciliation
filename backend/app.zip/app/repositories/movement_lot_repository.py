"""Data access for movement lots (Finacle Batch Booking True).

Write methods NEVER commit — ``lot_service.apply_lot_batch`` owns the
transaction so a whole DAG batch (lots + merges + members + keys) is atomic
and the cross-lot-key guard can roll everything back.

Raw-SQL notes: entry statuses are compared against the enum NAMES
('PENDING', 'MATCHED', ...) — that is what ORM-written rows store.
"""
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Sequence, Tuple

from sqlalchemy import literal_column, text
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import Session

from app.models.movement_lot import (
    LOT_STATUS_ACTIVE,
    LOT_STATUS_MERGED,
    MovementLot,
    MovementLotKey,
    MovementLotMember,
)
from app.models.reconciliation_entry import (
    EntryStatus,
    ReconciliationEntry,
    ReconciliationEntryEmargement,
)

logger = logging.getLogger(__name__)

# std.Payment.Status value for a payment still pending settlement. The lot view
# reaches a member's payments the SAME way the operational view does — via the
# member's entry (source_hash -> reconciliation_entry[_emargement].id ->
# reco.entry_payment_status.entry_id) — NOT by re-deriving a po_id from ref_no.
# The DAG (reco_payment_status) already explodes every payment of a movement
# into one entry_payment_status row per po_id, handling NDGB (ref_no=MessageID)
# and SCT/SDD/I/BLK direct bulks (pacs008 in remarks_1, NOT a PaymentNumber in
# ref_no), so summing entry_payment_status.amount over the PDNG rows yields the
# real pending total — precise even when only some payments of a bulk are PDNG.
PENDING_PAYMENT_STATUS = "PDNG"


class MovementLotRepository:
    # ------------------------------------------------------------------
    # DAG-facing writes (no commit — the service owns the transaction)
    # ------------------------------------------------------------------

    def get_key_map(self, db: Session, *, flow_source_id: int) -> List[Any]:
        """Every key of every ACTIVE lot of the source → (key_type, key_value,
        lot_id, lot_created_at). Merged lots' members were moved to their
        survivor, so the map always points at active lots."""
        return db.execute(
            text(
                """
                SELECT DISTINCT k.key_type, k.key_value, m.lot_id, l.created_at AS lot_created_at
                FROM reco.movement_lot_key k
                JOIN reco.movement_lot_member m ON m.id = k.member_id
                JOIN reco.movement_lot l ON l.id = m.lot_id
                WHERE l.flow_source_id = :fsid AND l.status = :active
                """
            ),
            {"fsid": flow_source_id, "active": LOT_STATUS_ACTIVE},
        ).fetchall()

    def create_lots(
        self, db: Session, *, flow_id: int, flow_source_id: int, lot_ids: Sequence[str]
    ) -> int:
        """Idempotent lot creation (a re-pushed batch after a crash is a no-op)."""
        if not lot_ids:
            return 0
        rows = [
            {
                "id": lot_id,
                "flow_id": flow_id,
                "flow_source_id": flow_source_id,
                "currency": "EUR",
                "status": LOT_STATUS_ACTIVE,
                "merge_conflict": False,
            }
            for lot_id in dict.fromkeys(lot_ids)
        ]
        stmt = pg_insert(MovementLot.__table__).values(rows).on_conflict_do_nothing(
            index_elements=["id"]
        )
        result = db.execute(stmt)
        return result.rowcount or 0

    def apply_merge(
        self, db: Session, *, absorbed_id: str, surviving_id: str, flow_source_id: int
    ) -> Dict[str, Any]:
        """Absorb one lot into another: move members, relink live PENDING
        entries (targeted UPDATE — never a re-push), flag the survivor when the
        absorbed lot already had emarged entries (they keep the old reco_id)."""
        lots = {
            lot.id: lot
            for lot in db.query(MovementLot)
            .filter(MovementLot.id.in_([absorbed_id, surviving_id]))
            .with_for_update()
            .all()
        }
        absorbed = lots.get(absorbed_id)
        surviving = lots.get(surviving_id)
        if absorbed is None or surviving is None:
            raise ValueError(f"merge references unknown lot(s): {absorbed_id} -> {surviving_id}")
        if absorbed.flow_source_id != flow_source_id or surviving.flow_source_id != flow_source_id:
            raise ValueError(f"merge {absorbed_id} -> {surviving_id} crosses flow sources")
        if absorbed.status == LOT_STATUS_MERGED:
            return {"members_moved": 0, "entries_relinked": 0, "skipped": True}
        # Defensive: a survivor absorbed by an earlier (out-of-band) merge —
        # follow the chain to the terminal lot.
        seen = set()
        while surviving.status == LOT_STATUS_MERGED and surviving.merged_into_lot_id:
            if surviving.id in seen:
                raise ValueError(f"merge chain cycle at lot {surviving.id}")
            seen.add(surviving.id)
            surviving = db.query(MovementLot).filter(
                MovementLot.id == surviving.merged_into_lot_id
            ).with_for_update().one()

        members_moved = (
            db.query(MovementLotMember)
            .filter(MovementLotMember.lot_id == absorbed.id)
            .update({"lot_id": surviving.id}, synchronize_session=False)
        )
        entries_relinked = (
            db.query(ReconciliationEntry)
            .filter(
                ReconciliationEntry.reco_id == absorbed.id,
                ReconciliationEntry.status == EntryStatus.PENDING,
            )
            .update({"reco_id": surviving.id}, synchronize_session=False)
        )
        emarged = (
            db.query(ReconciliationEntryEmargement.id)
            .filter(ReconciliationEntryEmargement.reco_id == absorbed.id)
            .limit(1)
            .first()
        )
        if emarged is not None:
            surviving.merge_conflict = True
            logger.warning(
                "[movement_lot] merge %s -> %s: absorbed lot has emarged entries "
                "keeping the old reco_id (merge_conflict flagged)",
                absorbed.id, surviving.id,
            )
        absorbed.status = LOT_STATUS_MERGED
        absorbed.merged_into_lot_id = surviving.id
        absorbed.merged_at = datetime.now(timezone.utc)
        return {
            "members_moved": members_moved,
            "entries_relinked": entries_relinked,
            "surviving_id": surviving.id,
        }

    def upsert_members(self, db: Session, rows: Sequence[dict]) -> Tuple[int, int, Dict[str, int]]:
        """Insert/refresh members keyed on source_hash. Amount/dates are part of
        the identity (immutable after insert, like the entry upsert); lot_id and
        the movement context follow re-clustering. Returns
        (inserted, updated, {source_hash: member_id})."""
        if not rows:
            return 0, 0, {}
        stmt = pg_insert(MovementLotMember.__table__).values(list(rows))
        stmt = stmt.on_conflict_do_update(
            index_elements=["source_hash"],
            set_={
                "lot_id": stmt.excluded.lot_id,
                "movement_type": stmt.excluded.movement_type,
                "transaction_particulars": stmt.excluded.transaction_particulars,
                "ref_no": stmt.excluded.ref_no,
                "remarks_1": stmt.excluded.remarks_1,
                "updated_at": text("now()"),
            },
        ).returning(
            literal_column("(xmax = 0)"),
            MovementLotMember.__table__.c.id,
            MovementLotMember.__table__.c.source_hash,
        )
        inserted = updated = 0
        ids_by_hash: Dict[str, int] = {}
        for is_insert, member_id, source_hash in db.execute(stmt).fetchall():
            ids_by_hash[source_hash] = member_id
            if is_insert:
                inserted += 1
            else:
                updated += 1
        return inserted, updated, ids_by_hash

    def insert_keys(self, db: Session, rows: Sequence[dict]) -> int:
        """Keys only ever accrue (late std.Payment data adds MSGID/PACS008 keys
        to an already-known member)."""
        if not rows:
            return 0
        deduped = {(r["member_id"], r["key_type"], r["key_value"]): r for r in rows}
        stmt = (
            pg_insert(MovementLotKey.__table__)
            .values(list(deduped.values()))
            .on_conflict_do_nothing(
                index_elements=["member_id", "key_type", "key_value"]
            )
        )
        result = db.execute(stmt)
        return result.rowcount or 0

    def sync_lot_currencies(self, db: Session, *, lot_ids: Sequence[str]) -> None:
        """Lot currency = its first member's (informational rollup)."""
        if not lot_ids:
            return
        db.execute(
            text(
                """
                UPDATE reco.movement_lot l
                SET currency = fm.currency
                FROM (
                    SELECT DISTINCT ON (lot_id) lot_id, currency
                    FROM reco.movement_lot_member
                    WHERE lot_id = ANY(:lot_ids)
                    ORDER BY lot_id, id
                ) fm
                WHERE fm.lot_id = l.id AND l.currency IS DISTINCT FROM fm.currency
                """
            ),
            {"lot_ids": list(lot_ids)},
        )

    def find_cross_lot_conflicts(
        self, db: Session, *, flow_source_id: int, limit: int = 5
    ) -> List[Any]:
        """Integrity guard: a key attached (via members) to more than one ACTIVE
        lot means the DAG clustered against a stale key map — the batch must be
        rolled back and the run retried."""
        return db.execute(
            text(
                """
                SELECT k.key_type, k.key_value, COUNT(DISTINCT m.lot_id) AS lot_count
                FROM reco.movement_lot_key k
                JOIN reco.movement_lot_member m ON m.id = k.member_id
                JOIN reco.movement_lot l ON l.id = m.lot_id
                WHERE l.flow_source_id = :fsid AND l.status = :active
                GROUP BY k.key_type, k.key_value
                HAVING COUNT(DISTINCT m.lot_id) > 1
                LIMIT :limit
                """
            ),
            {"fsid": flow_source_id, "active": LOT_STATUS_ACTIVE, "limit": limit},
        ).fetchall()

    def lots_exist(self, db: Session, *, lot_ids: Sequence[str]) -> set:
        if not lot_ids:
            return set()
        rows = db.query(MovementLot.id).filter(MovementLot.id.in_(list(lot_ids))).all()
        return {r[0] for r in rows}

    # ------------------------------------------------------------------
    # UI-facing reads (aggregates computed at read time)
    # ------------------------------------------------------------------

    _LOT_SELECT = f"""
        SELECT l.id, l.flow_id, l.flow_source_id, l.currency, l.status AS lot_status,
               l.merged_into_lot_id, l.merged_at, l.merge_conflict, l.created_at, l.updated_at,
               COALESCE(agg.member_count, 0) AS member_count,
               COALESCE(agg.total_debit, 0) AS total_debit,
               COALESCE(agg.total_credit, 0) AS total_credit,
               COALESCE(agg.net_amount, 0) AS net_amount,
               COALESCE(agg.currencies, ARRAY[]::varchar[]) AS currencies,
               COALESCE(agg.unbalanced_currencies, 0) AS unbalanced_currencies,
               agg.first_value_date, agg.last_value_date,
               COALESCE(st.pending_count, 0) AS pending_count,
               COALESCE(st.matched_count, 0) AS matched_count,
               COALESCE(st.excluded_count, 0) AS excluded_count,
               COALESCE(pp.pending_payment_amount, 0) AS pending_payment_amount,
               COALESCE(pp.pending_payment_count, 0) AS pending_payment_count
        FROM reco.movement_lot l
        LEFT JOIN LATERAL (
            SELECT COUNT(*) AS member_count,
                   COALESCE(SUM(CASE WHEN m.amount < 0 THEN m.amount ELSE 0 END), 0) AS total_debit,
                   COALESCE(SUM(CASE WHEN m.amount > 0 THEN m.amount ELSE 0 END), 0) AS total_credit,
                   COALESCE(SUM(m.amount), 0) AS net_amount,
                   ARRAY_AGG(DISTINCT m.currency) AS currencies,
                   MIN(m.value_date) AS first_value_date,
                   MAX(m.value_date) AS last_value_date,
                   (SELECT COUNT(*) FROM (
                        SELECT 1 FROM reco.movement_lot_member m2
                        WHERE m2.lot_id = l.id
                        GROUP BY m2.currency HAVING SUM(m2.amount) <> 0
                    ) unb) AS unbalanced_currencies
            FROM reco.movement_lot_member m
            WHERE m.lot_id = l.id
        ) agg ON TRUE
        LEFT JOIN LATERAL (
            SELECT COUNT(*) FILTER (WHERE le.status = 'PENDING') AS pending_count,
                   COUNT(*) FILTER (WHERE ee.status IN ('MATCHED', 'FORCED')) AS matched_count,
                   COUNT(*) FILTER (WHERE ee.status = 'EXCLUDED' OR le.status = 'EXCLUDED') AS excluded_count
            FROM reco.movement_lot_member m
            LEFT JOIN reco.reconciliation_entry le ON le.source_hash = m.source_hash
            LEFT JOIN reco.reconciliation_entry_emargement ee ON ee.source_hash = m.source_hash
            WHERE m.lot_id = l.id
        ) st ON TRUE
        LEFT JOIN LATERAL (
            -- Real pending amount: sum std.Payment amounts of the lot's DISTINCT
            -- PDNG payments. A payment (po_id) can be attached to several member
            -- entries of the lot (batch bookings share a MessageID/pacs008, so
            -- the payment-status sync fans it out per entry); it must count ONCE
            -- for the lot total, hence GROUP BY po_id before summing.
            SELECT COALESCE(SUM(dp.amount), 0) AS pending_payment_amount,
                   COUNT(*)                    AS pending_payment_count
            FROM (
                SELECT ep.po_id, MAX(ep.amount) AS amount
                FROM reco.movement_lot_member m
                LEFT JOIN reco.reconciliation_entry le            ON le.source_hash = m.source_hash
                LEFT JOIN reco.reconciliation_entry_emargement ee ON ee.source_hash = m.source_hash
                JOIN reco.entry_payment_status ep
                  ON ep.entry_id = COALESCE(le.id, ee.id)
                 AND ep.status   = '{PENDING_PAYMENT_STATUS}'
                WHERE m.lot_id = l.id
                GROUP BY ep.po_id
            ) dp
        ) pp ON TRUE
    """

    def _lot_filters(
        self,
        *,
        flow_id: Optional[int],
        status: Optional[str],
        balanced: Optional[bool],
        date_from: Optional[datetime],
        date_to: Optional[datetime],
        search: Optional[str],
        lot_id: Optional[str] = None,
    ) -> Tuple[str, Dict[str, Any]]:
        """(outer WHERE clause over the aggregated subquery, bind params)."""
        clauses: List[str] = []
        params: Dict[str, Any] = {}
        if lot_id is not None:
            clauses.append("id = :lot_id")
            params["lot_id"] = lot_id
        if flow_id is not None:
            clauses.append("flow_id = :flow_id")
            params["flow_id"] = flow_id
        if status == "merged":
            clauses.append("lot_status = 'merged'")
        elif status == "matched":
            clauses.append("lot_status = 'active' AND pending_count = 0 AND matched_count > 0")
        elif status == "pending":
            clauses.append("lot_status = 'active' AND (pending_count > 0 OR matched_count = 0)")
        if balanced is True:
            clauses.append("member_count > 0 AND unbalanced_currencies = 0")
        elif balanced is False:
            clauses.append("(member_count = 0 OR unbalanced_currencies > 0)")
        # Lots whose member activity window intersects [date_from, date_to]
        # (date_to inclusive: strictly before the next day).
        if date_from is not None:
            clauses.append("(last_value_date IS NULL OR last_value_date >= CAST(:date_from AS date))")
            params["date_from"] = date_from
        if date_to is not None:
            clauses.append("(first_value_date IS NULL OR first_value_date < (CAST(:date_to AS date) + 1))")
            params["date_to"] = date_to
        if search:
            clauses.append(
                "(id ILIKE :search_like OR EXISTS ("
                " SELECT 1 FROM reco.movement_lot_key k"
                " JOIN reco.movement_lot_member km ON km.id = k.member_id"
                " WHERE km.lot_id = lot_agg.id AND k.key_value ILIKE :search_like))"
            )
            params["search_like"] = f"%{search.strip()}%"
        where = (" WHERE " + " AND ".join(f"({c})" for c in clauses)) if clauses else ""
        return where, params

    def list_lots(
        self,
        db: Session,
        *,
        flow_id: Optional[int] = None,
        status: Optional[str] = None,
        balanced: Optional[bool] = None,
        date_from: Optional[datetime] = None,
        date_to: Optional[datetime] = None,
        search: Optional[str] = None,
        skip: int = 0,
        limit: int = 50,
    ) -> Tuple[List[Any], int]:
        where, params = self._lot_filters(
            flow_id=flow_id, status=status, balanced=balanced,
            date_from=date_from, date_to=date_to, search=search,
        )
        base = f"SELECT * FROM ({self._LOT_SELECT}) AS lot_agg{where}"
        total = db.execute(
            text(f"SELECT COUNT(*) FROM ({base}) AS c"), params
        ).scalar() or 0
        rows = db.execute(
            text(
                base
                + " ORDER BY last_value_date DESC NULLS LAST, created_at DESC"
                + " LIMIT :limit OFFSET :skip"
            ),
            {**params, "limit": limit, "skip": skip},
        ).fetchall()
        return rows, total

    def get_lot_summary(self, db: Session, *, lot_id: str) -> Optional[Any]:
        where, params = self._lot_filters(
            flow_id=None, status=None, balanced=None,
            date_from=None, date_to=None, search=None, lot_id=lot_id,
        )
        rows = db.execute(
            text(f"SELECT * FROM ({self._LOT_SELECT}) AS lot_agg{where}"), params
        ).fetchall()
        return rows[0] if rows else None

    _MEMBER_SELECT = """
        SELECT m.id, m.lot_id, m.source_hash, m.movement_type, m.external_ref,
               m.account, m.currency, m.amount, m.direction,
               m.value_date, m.operation_date,
               m.transaction_particulars, m.ref_no, m.remarks_1,
               COALESCE(le.status::text, ee.status::text) AS entry_status,
               COALESCE(le.id, ee.id) AS entry_id,
               COALESCE(le.match_group_id, ee.match_group_id) AS match_group_id
        FROM reco.movement_lot_member m
        LEFT JOIN reco.reconciliation_entry le ON le.source_hash = m.source_hash
        LEFT JOIN reco.reconciliation_entry_emargement ee ON ee.source_hash = m.source_hash
        WHERE m.lot_id = :lot_id
    """

    def list_members_with_status(self, db: Session, *, lot_id: str) -> List[Any]:
        """Members + their entry's status/id/match_group resolved through the
        live table first, the émargement table second (source_hash join)."""
        return db.execute(
            text(self._MEMBER_SELECT + " ORDER BY m.value_date, m.id"),
            {"lot_id": lot_id},
        ).fetchall()

    def list_members_page(
        self,
        db: Session,
        *,
        lot_id: str,
        skip: int = 0,
        limit: int = 100,
        movement_type: Optional[str] = None,
        direction: Optional[str] = None,
        entry_status: Optional[str] = None,
        search: Optional[str] = None,
        key_type: Optional[str] = None,
        key_value: Optional[str] = None,
    ) -> Tuple[List[Any], int]:
        """One page of members + total count. The key filter backs the
        aggregate-graph interaction (click a key node → its members)."""
        clauses: List[str] = []
        params: Dict[str, Any] = {"lot_id": lot_id}
        if movement_type:
            clauses.append("m.movement_type = :mtype")
            params["mtype"] = movement_type
        if direction:
            clauses.append("m.direction = :mdir")
            params["mdir"] = direction
        if entry_status:
            clauses.append("COALESCE(le.status::text, ee.status::text) = :estatus")
            params["estatus"] = entry_status.upper()
        if search:
            clauses.append(
                "(m.external_ref ILIKE :search_like OR m.ref_no ILIKE :search_like"
                " OR m.remarks_1 ILIKE :search_like"
                " OR m.transaction_particulars ILIKE :search_like)"
            )
            params["search_like"] = f"%{search.strip()}%"
        if key_type and key_value:
            clauses.append(
                "EXISTS (SELECT 1 FROM reco.movement_lot_key kf"
                " WHERE kf.member_id = m.id AND kf.key_type = :f_key_type"
                " AND kf.key_value = :f_key_value)"
            )
            params["f_key_type"] = key_type
            params["f_key_value"] = key_value
        base = self._MEMBER_SELECT + "".join(f" AND ({c})" for c in clauses)
        total = db.execute(
            text(f"SELECT COUNT(*) FROM ({base}) AS c"), params
        ).scalar() or 0
        rows = db.execute(
            text(base + " ORDER BY m.value_date, m.id LIMIT :limit OFFSET :skip"),
            {**params, "limit": limit, "skip": skip},
        ).fetchall()
        return rows, total

    def list_hub_keys(
        self, db: Session, *, lot_id: str, limit: int = 60
    ) -> Tuple[List[Any], int]:
        """Connective keys of a lot (carried by ≥ 2 members), busiest first —
        the skeleton of the aggregate graph. Returns (rows, hub_total)."""
        base = """
            SELECT k.key_type, k.key_value, COUNT(DISTINCT k.member_id) AS member_count
            FROM reco.movement_lot_key k
            JOIN reco.movement_lot_member m ON m.id = k.member_id
            WHERE m.lot_id = :lot_id
            GROUP BY k.key_type, k.key_value
            HAVING COUNT(DISTINCT k.member_id) >= 2
        """
        total = db.execute(
            text(f"SELECT COUNT(*) FROM ({base}) AS h"), {"lot_id": lot_id}
        ).scalar() or 0
        rows = db.execute(
            text(base + " ORDER BY member_count DESC, k.key_type, k.key_value LIMIT :limit"),
            {"lot_id": lot_id, "limit": limit},
        ).fetchall()
        return rows, total

    def aggregate_members_by_hub_keys(
        self, db: Session, *, lot_id: str, hub_ids: Sequence[str], limit: int = 150
    ) -> Tuple[List[Any], int]:
        """Members grouped by (movement_type, set of hub keys carried) — one
        aggregate-graph node per row. ``hub_ids`` are 'TYPE:value' strings
        (':' never appears in a key type); members carrying no hub key
        collapse into one 'isolated' group per movement_type (empty hub_sig).
        Returns (rows, group_total)."""
        base = """
            WITH member_hubs AS (
                SELECT m.id, m.movement_type, m.amount,
                       COALESCE(le.status::text, ee.status::text) AS entry_status,
                       COALESCE(
                           ARRAY_AGG(DISTINCT k.key_type || ':' || k.key_value)
                               FILTER (WHERE k.member_id IS NOT NULL),
                           ARRAY[]::text[]
                       ) AS hub_sig
                FROM reco.movement_lot_member m
                LEFT JOIN reco.reconciliation_entry le ON le.source_hash = m.source_hash
                LEFT JOIN reco.reconciliation_entry_emargement ee ON ee.source_hash = m.source_hash
                LEFT JOIN reco.movement_lot_key k
                    ON k.member_id = m.id
                    AND (k.key_type || ':' || k.key_value) = ANY(:hub_ids)
                WHERE m.lot_id = :lot_id
                GROUP BY m.id, m.movement_type, m.amount, le.status, ee.status
            ),
            groups AS (
                SELECT movement_type, hub_sig,
                       COUNT(*) AS member_count,
                       SUM(amount) AS total_amount,
                       COUNT(*) FILTER (WHERE entry_status = 'PENDING') AS pending_count,
                       COUNT(*) FILTER (WHERE entry_status IN ('MATCHED', 'FORCED')) AS matched_count,
                       COUNT(*) FILTER (WHERE entry_status = 'EXCLUDED') AS excluded_count
                FROM member_hubs
                GROUP BY movement_type, hub_sig
            )
            SELECT * FROM groups
        """
        params: Dict[str, Any] = {"lot_id": lot_id, "hub_ids": list(hub_ids)}
        total = db.execute(
            text(f"SELECT COUNT(*) FROM ({base}) AS g"), params
        ).scalar() or 0
        rows = db.execute(
            text(base + " ORDER BY member_count DESC, movement_type LIMIT :limit"),
            {**params, "limit": limit},
        ).fetchall()
        return rows, total

    def count_members_by_type(self, db: Session, *, lot_id: str) -> List[Any]:
        return db.execute(
            text(
                """
                SELECT movement_type, COUNT(*) AS member_count
                FROM reco.movement_lot_member
                WHERE lot_id = :lot_id
                GROUP BY movement_type
                ORDER BY movement_type
                """
            ),
            {"lot_id": lot_id},
        ).fetchall()

    def list_keys_for_lot(self, db: Session, *, lot_id: str) -> List[Any]:
        return db.execute(
            text(
                """
                SELECT k.id, k.member_id, k.key_type, k.key_value
                FROM reco.movement_lot_key k
                JOIN reco.movement_lot_member m ON m.id = k.member_id
                WHERE m.lot_id = :lot_id
                ORDER BY k.key_type, k.key_value, k.member_id
                """
            ),
            {"lot_id": lot_id},
        ).fetchall()

    # ------------------------------------------------------------------
    # Mega-aggregate graph (3 link nodes + movement nodes by type+direction)
    # ------------------------------------------------------------------

    def summarize_key_types(self, db: Session, *, lot_id: str) -> List[Any]:
        """One row per key type present in the lot: how many distinct values it
        carries (the 'number of links') and the total member↔key link count."""
        return db.execute(
            text(
                """
                SELECT k.key_type,
                       COUNT(DISTINCT k.key_value) AS distinct_count,
                       COUNT(*) AS member_link_count
                FROM reco.movement_lot_key k
                JOIN reco.movement_lot_member m ON m.id = k.member_id
                WHERE m.lot_id = :lot_id
                GROUP BY k.key_type
                ORDER BY k.key_type
                """
            ),
            {"lot_id": lot_id},
        ).fetchall()

    def aggregate_members_by_type_direction(
        self,
        db: Session,
        *,
        lot_id: str,
        key_type: Optional[str] = None,
        key_value: Optional[str] = None,
    ) -> List[Any]:
        """Movement nodes: members grouped by (movement_type, direction) with
        summed signed amount + status counts. When (key_type, key_value) is
        given, restrict to members carrying that exact key — the 'related nodes'
        surfaced when a value is picked in the drawer."""
        clause = ""
        params: Dict[str, Any] = {"lot_id": lot_id}
        if key_type and key_value:
            clause = (
                " AND EXISTS (SELECT 1 FROM reco.movement_lot_key kf"
                " WHERE kf.member_id = m.id AND kf.key_type = :key_type"
                " AND kf.key_value = :key_value)"
            )
            params["key_type"] = key_type
            params["key_value"] = key_value
        return db.execute(
            text(
                f"""
                WITH member_dir AS (
                    SELECT m.movement_type,
                           COALESCE(m.direction,
                                    CASE WHEN m.amount < 0 THEN 'debit' ELSE 'credit' END
                           ) AS direction,
                           m.amount,
                           le.status::text AS le_status,
                           ee.status::text AS ee_status,
                           COALESCE(le.id, ee.id) AS entry_id
                    FROM reco.movement_lot_member m
                    LEFT JOIN reco.reconciliation_entry le ON le.source_hash = m.source_hash
                    LEFT JOIN reco.reconciliation_entry_emargement ee ON ee.source_hash = m.source_hash
                    WHERE m.lot_id = :lot_id{clause}
                ),
                pending_by_group AS (
                    -- DISTINCT pending payment per (type, direction): a po_id
                    -- shared across several members of the group counts once.
                    SELECT g.movement_type, g.direction,
                           SUM(g.amount) AS pending_payment_amount
                    FROM (
                        SELECT md.movement_type, md.direction, ep.po_id,
                               MAX(ep.amount) AS amount
                        FROM member_dir md
                        JOIN reco.entry_payment_status ep
                          ON ep.entry_id = md.entry_id
                         AND ep.status = '{PENDING_PAYMENT_STATUS}'
                        GROUP BY md.movement_type, md.direction, ep.po_id
                    ) g
                    GROUP BY g.movement_type, g.direction
                )
                SELECT md.movement_type, md.direction,
                       COUNT(*) AS member_count,
                       COALESCE(SUM(md.amount), 0) AS total_amount,
                       COUNT(*) FILTER (WHERE md.le_status = 'PENDING') AS pending_count,
                       COUNT(*) FILTER (WHERE md.ee_status IN ('MATCHED', 'FORCED')) AS matched_count,
                       COUNT(*) FILTER (WHERE md.ee_status = 'EXCLUDED' OR md.le_status = 'EXCLUDED') AS excluded_count,
                       COALESCE(pg.pending_payment_amount, 0) AS pending_payment_amount
                FROM member_dir md
                LEFT JOIN pending_by_group pg
                  ON pg.movement_type = md.movement_type AND pg.direction = md.direction
                GROUP BY md.movement_type, md.direction, pg.pending_payment_amount
                ORDER BY member_count DESC, md.movement_type, md.direction
                """
            ),
            params,
        ).fetchall()

    def list_graph_edges(self, db: Session, *, lot_id: str) -> List[Any]:
        """Distinct (movement_type, direction, key_type) triples — which movement
        node connects to which of the 3 link nodes."""
        return db.execute(
            text(
                """
                SELECT DISTINCT m.movement_type,
                       COALESCE(m.direction,
                                CASE WHEN m.amount < 0 THEN 'debit' ELSE 'credit' END
                       ) AS direction,
                       k.key_type
                FROM reco.movement_lot_member m
                JOIN reco.movement_lot_key k ON k.member_id = m.id
                WHERE m.lot_id = :lot_id
                """
            ),
            {"lot_id": lot_id},
        ).fetchall()

    def list_key_values(
        self,
        db: Session,
        *,
        lot_id: str,
        key_type: str,
        search: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> Tuple[List[Any], int]:
        """Paginated distinct values of one key type (+ member count each) —
        the drawer list opened when a link node is clicked."""
        clauses = ["m.lot_id = :lot_id", "k.key_type = :key_type"]
        params: Dict[str, Any] = {"lot_id": lot_id, "key_type": key_type}
        if search:
            clauses.append("k.key_value ILIKE :search_like")
            params["search_like"] = f"%{search.strip()}%"
        base = f"""
            SELECT k.key_value, COUNT(DISTINCT k.member_id) AS member_count
            FROM reco.movement_lot_key k
            JOIN reco.movement_lot_member m ON m.id = k.member_id
            WHERE {' AND '.join(clauses)}
            GROUP BY k.key_value
        """
        total = db.execute(
            text(f"SELECT COUNT(*) FROM ({base}) AS c"), params
        ).scalar() or 0
        rows = db.execute(
            text(base + " ORDER BY member_count DESC, k.key_value LIMIT :limit OFFSET :skip"),
            {**params, "limit": limit, "skip": skip},
        ).fetchall()
        return rows, total


movement_lot_repository = MovementLotRepository()
